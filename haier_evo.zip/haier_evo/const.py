DOMAIN = "haier_evo"
